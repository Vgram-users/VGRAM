# VGram 0.6 APK — анализ

- APK: `VGram-0.6.apk`
- Размер: 18,773,261 bytes
- SHA-256: `d33343d0dacebc390cb819b3ebc3fcce003ec86cc101d1bd31519b81440d0d0d`
- DEX: `classes.dex` (DEX 039), 1,297,764 bytes
- Всего DEX-классов: 3,737
- Классов приложения `dev.vgram.app`: 98
- Архитектуры: `arm64-v8a`, `armeabi-v7a`
- Нативная библиотека: `libtdjni.so` для обеих ABI
- Ресурсы: 9 файлов `res/`, `resources.arsc`
- Основные классы приложения: `VgramApplication`, `TelegramService`, `LoginActivity`, `MainActivity`, `ChatActivity`, `SplashActivity`, `AuroraView`, `GlassButton`, `GlassDrawable`.

## Важное ограничение

APK содержит DEX-байткод, а не исходные `.java`/`.kt`. Для получения читаемого Java-представления требуется JADX; для ресурсов/манифеста — Apktool. В текущем окружении этих декомпиляторов нет, а исходящие сетевые загрузки недоступны. Поэтому этот пакет — инвентаризация и извлечённые бинарные материалы, не готовый компилируемый Android Studio проект.

## Содержимое APK

```text
AndroidManifest.xml
resources.arsc
classes.dex
assets/modules/index.json
lib/arm64-v8a/libtdjni.so
lib/armeabi-v7a/libtdjni.so
```

Полный список классов приложения находится в `APP_CLASSES.txt`.
